package org.efrei.start.models;
import jakarta.persistence.*;
import org.efrei.start.global.Category;

import java.util.List;

@Entity
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(name = "title", nullable = false, length = 50)
    private String title;

    /*@OneToOne
    private Actor actor;*/

    @Enumerated(EnumType.STRING)
    private Category category;

    public Movie(String title ) {
        this.title = title;

    }

    public Movie() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @ManyToMany
    @JoinTable(name = "movie_acteur",
            joinColumns = @JoinColumn(name = "film_id"),
            inverseJoinColumns = @JoinColumn(name = "acteur_id"))
    private List<Actor> acteurs;




}
