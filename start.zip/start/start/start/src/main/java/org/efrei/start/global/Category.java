package org.efrei.start.global;

public enum Category {

    ACTION,
    HORROR,
    DRAMA


}
