package org.efrei.start.dto;

import org.efrei.start.global.Category;
import org.efrei.start.models.Actor;

import java.util.List;

public class CreateMovie {

    private String title;

    private Category category;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


}
