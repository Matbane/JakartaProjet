package org.efrei.start.models;
import jakarta.persistence.*;
import java.util.List;


public class Studio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private String id;

    private String name;

    // Relation One-to-Many avec Film
    @OneToMany(mappedBy = "studio", cascade = CascadeType.ALL)
    private List<Movie> films;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Movie> getFilms() {
        return films;
    }

    public void setFilms(List<Movie> films) {
        this.films = films;
    }

}
